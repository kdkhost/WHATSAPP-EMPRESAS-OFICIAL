<?php

use Illuminate\Support\Facades\Route;
use App\Addons\gestao_financeira\Http\Controllers\DashboardController;
use App\Addons\gestao_financeira\Http\Controllers\TransactionController;
use App\Addons\gestao_financeira\Http\Controllers\CategoryController;
use App\Addons\gestao_financeira\Http\Controllers\AccountController;
use App\Addons\gestao_financeira\Http\Controllers\ReportController;

// Painel principal / Dashboard
Route::get('/', [DashboardController::class, 'index'])->name('index');

// Gestão de Transações (Receitas e Despesas)
Route::prefix('transacoes')->name('transactions.')->group(function () {
    Route::get('/', [TransactionController::class, 'index'])->name('index');
    Route::get('/criar', [TransactionController::class, 'create'])->name('create');
    Route::post('/salvar', [TransactionController::class, 'store'])->name('store');
    Route::get('/{transaction}/editar', [TransactionController::class, 'edit'])->name('edit');
    Route::post('/{transaction}/atualizar', [TransactionController::class, 'update'])->name('update');
    Route::delete('/{transaction}/excluir', [TransactionController::class, 'destroy'])->name('destroy');
    Route::post('/{transaction}/pagar', [TransactionController::class, 'pay'])->name('pay'); // Atalho para marcar como pago
});

// Gestão de Categorias
Route::prefix('categorias')->name('categories.')->group(function () {
    Route::get('/', [CategoryController::class, 'index'])->name('index');
    Route::post('/salvar', [CategoryController::class, 'store'])->name('store');
    Route::post('/{category}/atualizar', [CategoryController::class, 'update'])->name('update');
    Route::delete('/{category}/excluir', [CategoryController::class, 'destroy'])->name('destroy');
});

// Gestão de Contas Bancárias / Carteiras
Route::prefix('contas')->name('accounts.')->group(function () {
    Route::get('/', [AccountController::class, 'index'])->name('index');
    Route::post('/salvar', [AccountController::class, 'store'])->name('store');
    Route::post('/{account}/atualizar', [AccountController::class, 'update'])->name('update');
    Route::delete('/{account}/excluir', [AccountController::class, 'destroy'])->name('destroy');
});

// Relatórios
Route::prefix('relatorios')->name('reports.')->group(function () {
    Route::get('/', [ReportController::class, 'index'])->name('index');
    Route::get('/fluxo-de-caixa', [ReportController::class, 'cashFlow'])->name('cash_flow');
    Route::get('/dre', [ReportController::class, 'dre'])->name('dre');
});
