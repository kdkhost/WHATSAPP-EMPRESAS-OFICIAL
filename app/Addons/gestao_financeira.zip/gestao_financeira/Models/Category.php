<?php

namespace App\Addons\gestao_financeira\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Category extends Model
{
    /**
     * Tabela associada ao modelo.
     */
    protected $table = 'addon_gestao_financeira_categories';

    /**
     * Atributos atribuíveis em massa.
     */
    protected $fillable = [
        'name',
        'type',
        'color',
    ];

    /**
     * Transações associadas a esta categoria.
     */
    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class, 'category_id');
    }
}
