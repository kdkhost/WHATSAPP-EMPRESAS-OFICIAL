<?php

namespace App\Addons\gestao_financeira;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class AddonServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Bindings, singletons or config merges
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // 1. Carrega as rotas com prefixo, nome e middlewares adequados
        Route::middleware(['web', 'admin', 'module.permission:gestao-financeira.view'])
            ->prefix('admin/gestao-financeira')
            ->name('admin.gestao-financeira.')
            ->group(function () {
                require __DIR__ . '/routes/web.php';
            });

        // 2. Carrega as views Blade do addon (vinculadas sob gestao-financeira::)
        $this->loadViewsFrom(__DIR__ . '/Resources/views', 'gestao-financeira');

        // 3. Carrega as migrations de tabelas do addon
        $this->loadMigrationsFrom(__DIR__ . '/database/migrations');

        // 4. Integração opcional com CronManager para relatórios diários de resumo no WhatsApp
        if (class_exists(\App\Services\CronManager::class)) {
            try {
                \App\Services\CronManager::register(
                    name: 'gestao-financeira.daily-report',
                    callback: fn() => $this->sendDailyFinancialReport(),
                    intervalMinutes: 1440, // 24 horas
                    description: 'Envia resumo financeiro diário por WhatsApp para o administrador'
                );
            } catch (\Exception $e) {
                // Silencia exceções para não interromper a inicialização do app
            }
        }
    }

    /**
     * Callback simulado para envio do relatório diário pelo WhatsApp
     */
    protected function sendDailyFinancialReport(): void
    {
        try {
            // Verifica as configurações do addon
            $settings = null;
            if (class_exists(\App\Models\Addon::class)) {
                $addon = \App\Models\Addon::where('slug', 'gestao-financeira')->first();
                $settings = $addon ? json_decode($addon->settings, true) : null;
            }

            if (!$settings || !($settings['alerts_enabled'] ?? false) || empty($settings['alerts_whatsapp_number'])) {
                return;
            }

            // Lógica para enviar resumo no WhatsApp utilizando o serviço nativo da plataforma
            $hoje = now()->format('Y-m-d');
            
            // Buscar dados de receitas e despesas do dia
            $receitas = \DB::table('addon_gestao_financeira_transactions')
                ->where('type', 'receita')
                ->whereDate('payment_date', $hoje)
                ->sum('amount');

            $despesas = \DB::table('addon_gestao_financeira_transactions')
                ->where('type', 'despesa')
                ->whereDate('payment_date', $hoje)
                ->sum('amount');

            $saldo = $receitas - $despesas;
            
            $mensagem = "📊 *RESUMO FINANCEIRO DIÁRIO* 📊\n\n";
            $mensagem .= "📅 Data: " . now()->format('d/m/Y') . "\n\n";
            $mensagem .= "💰 Receitas Recebidas: R$ " . number_format($receitas, 2, ',', '.') . "\n";
            $mensagem .= "💸 Despesas Pagas: R$ " . number_format($despesas, 2, ',', '.') . "\n";
            $mensagem .= "➡️ Saldo do Dia: R$ " . number_format($saldo, 2, ',', '.') . "\n\n";
            $mensagem .= "Tenha um ótimo dia de trabalho!";

            // Dispara via serviço de envio padrão do painel se existir
            if (class_exists(\App\Services\WhatsappService::class)) {
                \App\Services\WhatsappService::sendMessage($settings['alerts_whatsapp_number'], $mensagem);
            }
        } catch (\Exception $e) {
            \Log::error("Erro no envio do relatório financeiro via cron: " . $e->getMessage());
        }
    }
}
