<?php

namespace App\Addons\gestao_financeira\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Addons\gestao_financeira\Models\Transaction;
use App\Addons\gestao_financeira\Models\Category;
use App\Addons\gestao_financeira\Models\Account;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    /**
     * Tela inicial de relatórios com atalhos.
     */
    public function index()
    {
        return view('gestao-financeira::reports.index');
    }

    /**
     * Relatório de Fluxo de Caixa.
     */
    public function cashFlow(Request $request)
    {
        $ano = $request->input('year', now()->year);

        // Agrupa receitas e despesas por mês do ano selecionado
        $rawTransactions = Transaction::select(
            DB::raw('MONTH(due_date) as mes'),
            'type',
            'status',
            DB::raw('SUM(amount) as total')
        )
        ->whereYear('due_date', $ano)
        ->groupBy('mes', 'type', 'status')
        ->get();

        // Estrutura os dados por mês
        $monthsData = [];
        for ($m = 1; $m <= 12; $m++) {
            $monthsData[$m] = [
                'receitas_pagas' => 0,
                'receitas_pendentes' => 0,
                'despesas_pagas' => 0,
                'despesas_pendentes' => 0,
            ];
        }

        foreach ($rawTransactions as $row) {
            $mes = (int)$row->mes;
            if ($row->type === 'receita') {
                if ($row->status === 'pago') {
                    $monthsData[$mes]['receitas_pagas'] = (float)$row->total;
                } else {
                    $monthsData[$mes]['receitas_pendentes'] = (float)$row->total;
                }
            } else {
                if ($row->status === 'pago') {
                    $monthsData[$mes]['despesas_pagas'] = (float)$row->total;
                } else {
                    $monthsData[$mes]['despesas_pendentes'] = (float)$row->total;
                }
            }
        }

        return view('gestao-financeira::reports.fluxo-caixa', compact('monthsData', 'ano'));
    }

    /**
     * Demonstrativo de Resultados do Exercício (DRE).
     */
    public function dre(Request $request)
    {
        // Define período (padrão: ano atual)
        $ano = $request->input('year', now()->year);
        $startDate = "{$ano}-01-01";
        $endDate = "{$ano}-12-31";

        // 1. Obter todas as receitas agrupadas por categoria
        $receitasPorCategoria = DB::table('addon_gestao_financeira_transactions as t')
            ->join('addon_gestao_financeira_categories as c', 't.category_id', '=', 'c.id')
            ->select('c.name', DB::raw('SUM(t.amount) as total'))
            ->where('t.type', 'receita')
            ->where('t.status', 'pago')
            ->whereBetween('t.payment_date', [$startDate, $endDate])
            ->groupBy('c.name')
            ->orderBy('total', 'desc')
            ->get();

        // 2. Obter todas as despesas agrupadas por categoria
        $despesasPorCategoria = DB::table('addon_gestao_financeira_transactions as t')
            ->join('addon_gestao_financeira_categories as c', 't.category_id', '=', 'c.id')
            ->select('c.name', DB::raw('SUM(t.amount) as total'))
            ->where('t.type', 'despesa')
            ->where('t.status', 'pago')
            ->whereBetween('t.payment_date', [$startDate, $endDate])
            ->groupBy('c.name')
            ->orderBy('total', 'desc')
            ->get();

        $totalReceitas = $receitasPorCategoria->sum('total');
        $totalDespesas = $despesasPorCategoria->sum('total');
        $lucroLiquido = $totalReceitas - $totalDespesas;

        // Calcular Margem Líquida
        $margemLiquida = $totalReceitas > 0 ? ($lucroLiquido / $totalReceitas) * 100 : 0;

        return view('gestao-financeira::reports.dre', compact(
            'receitasPorCategoria',
            'despesasPorCategoria',
            'totalReceitas',
            'totalDespesas',
            'lucroLiquido',
            'margemLiquida',
            'ano'
        ));
    }
}
