<?php

namespace App\Addons\gestao_financeira\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Addons\gestao_financeira\Models\Account;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    /**
     * Lista as contas / carteiras cadastradas.
     */
    public function index()
    {
        $accounts = Account::withCount('transactions')
            ->orderBy('name')
            ->get();

        return view('gestao-financeira::accounts.index', compact('accounts'));
    }

    /**
     * Cadastra nova conta bancária ou carteira digital.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'type' => 'required|in:banco,digital,dinheiro,cartao,outro',
            'initial_balance' => 'required|numeric',
            'description' => 'nullable|string',
        ]);

        $data = $request->only(['name', 'type', 'initial_balance', 'description']);
        // O saldo atual inicializará como igual ao saldo inicial
        $data['current_balance'] = $data['initial_balance'];

        Account::create($data);

        return redirect()->route('admin.gestao-financeira.accounts.index')
            ->with('success', 'Conta cadastrada com sucesso!');
    }

    /**
     * Atualiza as informações da conta.
     */
    public function update(Request $request, Account $account)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'type' => 'required|in:banco,digital,dinheiro,cartao,outro',
            'description' => 'nullable|string',
        ]);

        $account->update($request->only(['name', 'type', 'description']));

        return redirect()->route('admin.gestao-financeira.accounts.index')
            ->with('success', 'Conta atualizada com sucesso!');
    }

    /**
     * Exclui a conta se não tiver transações ou move/limpa os vinculos.
     */
    public function destroy(Account $account)
    {
        $count = $account->transactions()->count();
        if ($count > 0) {
            return redirect()->route('admin.gestao-financeira.accounts.index')
                ->with('error', "Não é possível excluir esta conta porque existem {$count} transações vinculadas a ela. Exclua ou transfira os lançamentos primeiro.");
        }

        $account->delete();

        return redirect()->route('admin.gestao-financeira.accounts.index')
            ->with('success', 'Conta excluída com sucesso!');
    }
}
