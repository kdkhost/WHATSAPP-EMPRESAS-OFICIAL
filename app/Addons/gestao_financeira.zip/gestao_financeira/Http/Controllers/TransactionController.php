<?php

namespace App\Addons\gestao_financeira\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Addons\gestao_financeira\Models\Transaction;
use App\Addons\gestao_financeira\Models\Account;
use App\Addons\gestao_financeira\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TransactionController extends Controller
{
    /**
     * Lista transações filtradas.
     */
    public function index(Request $request)
    {
        $query = Transaction::with(['category', 'account']);

        // Filtro de Busca por descrição
        if ($request->filled('search')) {
            $query->where('description', 'like', '%' . $request->search . '%');
        }

        // Filtro de Tipo
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        // Filtro de Status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filtro de Categoria
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        // Filtro de Conta
        if ($request->filled('account_id')) {
            $query->where('account_id', $request->account_id);
        }

        // Filtro de Período (Padrão: Mês atual se nenhum informado)
        $startDate = $request->input('start_date', now()->startOfMonth()->toDateString());
        $endDate = $request->input('end_date', now()->endOfMonth()->toDateString());

        $query->where(function ($q) use ($startDate, $endDate) {
            $q->whereBetween('due_date', [$startDate, $endDate])
              ->orWhereBetween('payment_date', [$startDate, $endDate]);
        });

        $transactions = $query->orderBy('due_date', 'desc')->paginate(20)->withQueryString();

        $accounts = Account::orderBy('name')->get();
        $categories = Category::orderBy('name')->get();

        return view('gestao-financeira::transactions.index', compact('transactions', 'accounts', 'categories', 'startDate', 'endDate'));
    }

    /**
     * Formulário para cadastrar lançamento.
     */
    public function create()
    {
        $accounts = Account::orderBy('name')->get();
        $categories = Category::orderBy('name')->get();
        return view('gestao-financeira::transactions.create', compact('accounts', 'categories'));
    }

    /**
     * Salva o lançamento.
     */
    public function store(Request $request)
    {
        $request->validate([
            'type' => 'required|in:receita,despesa',
            'description' => 'required|string|max:255',
            'amount' => 'required|numeric|min:0.01',
            'due_date' => 'required|date',
            'payment_date' => 'nullable|required_if:status,pago|date',
            'status' => 'required|in:pago,pendente',
            'account_id' => 'required|exists:addon_gestao_financeira_accounts,id',
            'category_id' => 'required|exists:addon_gestao_financeira_categories,id',
            'notes' => 'nullable|string',
            'attachment' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:4096',
        ]);

        $data = $request->only([
            'type', 'description', 'amount', 'due_date', 
            'payment_date', 'status', 'account_id', 'category_id', 'notes'
        ]);

        // Ajusta data de pagamento caso não esteja preenchida mas esteja pago
        if ($data['status'] === 'pago' && empty($data['payment_date'])) {
            $data['payment_date'] = now()->toDateString();
        }

        // Upload de anexo/comprovante
        if ($request->hasFile('attachment')) {
            $path = $request->file('attachment')->store('addons/financeiro/attachments', 'public');
            $data['attachment_path'] = $path;
        }

        Transaction::create($data);

        return redirect()->route('admin.gestao-financeira.transactions.index')
            ->with('success', 'Lançamento cadastrado com sucesso!');
    }

    /**
     * Tela de edição de transação.
     */
    public function edit(Transaction $transaction)
    {
        $accounts = Account::orderBy('name')->get();
        $categories = Category::orderBy('name')->get();
        return view('gestao-financeira::transactions.edit', compact('transaction', 'accounts', 'categories'));
    }

    /**
     * Atualiza a transação.
     */
    public function update(Request $request, Transaction $transaction)
    {
        $request->validate([
            'type' => 'required|in:receita,despesa',
            'description' => 'required|string|max:255',
            'amount' => 'required|numeric|min:0.01',
            'due_date' => 'required|date',
            'payment_date' => 'nullable|required_if:status,pago|date',
            'status' => 'required|in:pago,pendente',
            'account_id' => 'required|exists:addon_gestao_financeira_accounts,id',
            'category_id' => 'required|exists:addon_gestao_financeira_categories,id',
            'notes' => 'nullable|string',
            'attachment' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:4096',
        ]);

        $data = $request->only([
            'type', 'description', 'amount', 'due_date', 
            'payment_date', 'status', 'account_id', 'category_id', 'notes'
        ]);

        if ($data['status'] === 'pago' && empty($data['payment_date'])) {
            $data['payment_date'] = now()->toDateString();
        } elseif ($data['status'] === 'pendente') {
            $data['payment_date'] = null;
        }

        // Se enviou novo anexo, limpa o antigo
        if ($request->hasFile('attachment')) {
            if ($transaction->attachment_path) {
                Storage::disk('public')->delete($transaction->attachment_path);
            }
            $path = $request->file('attachment')->store('addons/financeiro/attachments', 'public');
            $data['attachment_path'] = $path;
        }

        $transaction->update($data);

        return redirect()->route('admin.gestao-financeira.transactions.index')
            ->with('success', 'Lançamento atualizado com sucesso!');
    }

    /**
     * Remove a transação.
     */
    public function destroy(Transaction $transaction)
    {
        if ($transaction->attachment_path) {
            Storage::disk('public')->delete($transaction->attachment_path);
        }
        
        $transaction->delete();

        return redirect()->route('admin.gestao-financeira.transactions.index')
            ->with('success', 'Lançamento excluído com sucesso!');
    }

    /**
     * Marca uma transação pendente como paga.
     */
    public function pay(Transaction $transaction)
    {
        $transaction->update([
            'status' => 'pago',
            'payment_date' => now()->toDateString()
        ]);

        return redirect()->back()->with('success', 'Lançamento marcado como Pago e saldo atualizado!');
    }
}
