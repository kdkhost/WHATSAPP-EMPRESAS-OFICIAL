<?php

namespace App\Addons\gestao_financeira\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Addons\gestao_financeira\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Lista as categorias cadastradas.
     */
    public function index()
    {
        $categories = Category::withCount('transactions')
            ->orderBy('type')
            ->orderBy('name')
            ->get();

        return view('gestao-financeira::categories.index', compact('categories'));
    }

    /**
     * Cadastra nova categoria.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'type' => 'required|in:receita,despesa',
            'color' => 'required|string|size:7|regex:/^#[0-9A-Fa-f]{6}$/',
        ]);

        Category::create($request->only(['name', 'type', 'color']));

        return redirect()->route('admin.gestao-financeira.categories.index')
            ->with('success', 'Categoria cadastrada com sucesso!');
    }

    /**
     * Atualiza categoria.
     */
    public function update(Request $request, Category $category)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'type' => 'required|in:receita,despesa',
            'color' => 'required|string|size:7|regex:/^#[0-9A-Fa-f]{6}$/',
        ]);

        $category->update($request->only(['name', 'type', 'color']));

        return redirect()->route('admin.gestao-financeira.categories.index')
            ->with('success', 'Categoria atualizada com sucesso!');
    }

    /**
     * Remove categoria.
     */
    public function destroy(Category $category)
    {
        // Embora onDelete('set null') esteja na migration,
        // é uma boa prática notificar se há transações vinculadas.
        $count = $category->transactions()->count();
        $message = 'Categoria excluída com sucesso!';
        if ($count > 0) {
            $message = "Categoria excluída! O Módulo redefiniu {$count} lançamentos vinculados para 'Sem Categoria'.";
        }

        $category->delete();

        return redirect()->route('admin.gestao-financeira.categories.index')
            ->with('success', $message);
    }
}
