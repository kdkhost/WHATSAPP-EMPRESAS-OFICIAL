<?php

namespace App\Addons\gestao_financeira\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Addons\gestao_financeira\Models\Transaction;
use App\Addons\gestao_financeira\Models\Account;
use App\Addons\gestao_financeira\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    /**
     * Exibe o painel financeiro principal.
     */
    public function index()
    {
        $hoje = now();
        $inicioMes = $hoje->copy()->startOfMonth();
        $fimMes = $hoje->copy()->endOfMonth();

        // 1. Saldos rápidos do mês corrente
        $receitasRecebidas = Transaction::where('type', 'receita')
            ->where('status', 'pago')
            ->whereBetween('payment_date', [$inicioMes, $fimMes])
            ->sum('amount');

        $receitasPendentes = Transaction::where('type', 'receita')
            ->where('status', 'pendente')
            ->whereBetween('due_date', [$inicioMes, $fimMes])
            ->sum('amount');

        $despesasPagas = Transaction::where('type', 'despesa')
            ->where('status', 'pago')
            ->whereBetween('payment_date', [$inicioMes, $fimMes])
            ->sum('amount');

        $despesasPendentes = Transaction::where('type', 'despesa')
            ->where('status', 'pendente')
            ->whereBetween('due_date', [$inicioMes, $fimMes])
            ->sum('amount');

        $saldoMes = $receitasRecebidas - $despesasPagas;

        // 2. Saldo consolidado das contas financeiras
        $saldoContas = Account::sum('current_balance');
        $contas = Account::orderBy('name')->get();

        // 3. Lançamentos recentes (últimos 8)
        $recentTransactions = Transaction::with(['category', 'account'])
            ->orderBy('created_at', 'desc')
            ->limit(8)
            ->get();

        // 4. Lançamentos a vencer (próximos 7 dias)
        $upcomingTransactions = Transaction::with(['category', 'account'])
            ->where('status', 'pendente')
            ->whereBetween('due_date', [$hoje->toDateString(), $hoje->copy()->addDays(7)->toDateString()])
            ->orderBy('due_date', 'asc')
            ->get();

        // 5. Dados para o gráfico de fluxo de caixa dos últimos 6 meses
        $chartData = $this->getMonthlyFlowData();

        return view('gestao-financeira::dashboard', compact(
            'receitasRecebidas',
            'receitasPendentes',
            'despesasPagas',
            'despesasPendentes',
            'saldoMes',
            'saldoContas',
            'contas',
            'recentTransactions',
            'upcomingTransactions',
            'chartData'
        ));
    }

    /**
     * Agrupa e retorna receitas e despesas dos últimos 6 meses para renderizar gráficos.
     */
    protected function getMonthlyFlowData(): array
    {
        $months = [];
        $incomeData = [];
        $expenseData = [];

        for ($i = 5; $i >= 0; $i--) {
            $date = now()->subMonths($i);
            $monthName = $date->translatedFormat('M/Y'); // ex: Mai/2026
            $start = $date->copy()->startOfMonth()->toDateString();
            $end = $date->copy()->endOfMonth()->toDateString();

            $months[] = $monthName;

            // Soma de receitas pagas no mês
            $incomeData[] = Transaction::where('type', 'receita')
                ->where('status', 'pago')
                ->whereBetween('payment_date', [$start, $end])
                ->sum('amount');

            // Soma de despesas pagas no mês
            $expenseData[] = Transaction::where('type', 'despesa')
                ->where('status', 'pago')
                ->whereBetween('payment_date', [$start, $end])
                ->sum('amount');
        }

        return [
            'labels' => $months,
            'receitas' => $incomeData,
            'despesas' => $expenseData
        ];
    }
}
