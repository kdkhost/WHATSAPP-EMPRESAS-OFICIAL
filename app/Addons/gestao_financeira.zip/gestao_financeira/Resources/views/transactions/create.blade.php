@extends(\Illuminate\Support\Facades\View::exists('admin.layouts.master') ? 'admin.layouts.master' : (\Illuminate\Support\Facades\View::exists('admin.master') ? 'admin.master' : 'gestao-financeira::layouts.master'))

@section('title', 'Novo Lançamento')
@section('page_title', 'Cadastrar Lançamento')

@section('content')
<div class="max-w-3xl mx-auto">
    <div class="mb-6 flex justify-between items-center">
        <a href="{{ route('admin.gestao-financeira.transactions.index') }}" class="text-xs text-slate-400 hover:text-slate-200 font-semibold flex items-center gap-1.5 transition-colors">
            <i class="bi bi-chevron-left"></i> Voltar para a lista
        </a>
    </div>

    <!-- Card de Formulário -->
    <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 md:p-8 glass-card shadow-xl" x-data="{ type: 'receita', status: 'pendente' }">
        <form action="{{ route('admin.gestao-financeira.transactions.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf

            <!-- Tipo de Lançamento (Receita vs Despesa) -->
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Tipo de Lançamento</label>
                <div class="grid grid-cols-2 gap-4">
                    <!-- Receita Radio -->
                    <label class="relative flex items-center justify-center p-4 rounded-xl border border-slate-800 bg-slate-950/40 cursor-pointer transition-all duration-200 hover:bg-slate-900/40"
                           :class="type === 'receita' ? 'border-emerald-500/50 bg-emerald-500/5 ring-1 ring-emerald-500/30' : ''">
                        <input type="radio" name="type" value="receita" x-model="type" class="sr-only" checked>
                        <div class="flex items-center gap-3">
                            <span class="w-6 h-6 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                                <i class="bi bi-arrow-down-left"></i>
                            </span>
                            <span class="text-sm font-bold text-slate-200">Receita (Entrada)</span>
                        </div>
                    </label>

                    <!-- Despesa Radio -->
                    <label class="relative flex items-center justify-center p-4 rounded-xl border border-slate-800 bg-slate-950/40 cursor-pointer transition-all duration-200 hover:bg-slate-900/40"
                           :class="type === 'despesa' ? 'border-rose-500/50 bg-rose-500/5 ring-1 ring-rose-500/30' : ''">
                        <input type="radio" name="type" value="despesa" x-model="type" class="sr-only">
                        <div class="flex items-center gap-3">
                            <span class="w-6 h-6 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400">
                                <i class="bi bi-arrow-up-right"></i>
                            </span>
                            <span class="text-sm font-bold text-slate-200">Despesa (Saída)</span>
                        </div>
                    </label>
                </div>
            </div>

            <!-- Grid de Campos Principais -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Descrição -->
                <div class="md:col-span-2">
                    <label for="description" class="block text-xs font-semibold text-slate-300 mb-2">Descrição / Título *</label>
                    <input type="text" name="description" id="description" required placeholder="Ex: Recebimento de Projeto Web, Assinatura Servidor..."
                           class="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-brand-500 transition-colors">
                </div>

                <!-- Valor -->
                <div>
                    <label for="amount" class="block text-xs font-semibold text-slate-300 mb-2">Valor (R$) *</label>
                    <div class="relative">
                        <input type="number" step="0.01" name="amount" id="amount" required placeholder="0,00"
                               class="w-full pl-12 pr-4 py-2.5 text-sm rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-brand-500 transition-colors">
                        <div class="absolute left-4 top-3 text-sm font-bold text-slate-500">R$</div>
                    </div>
                </div>

                <!-- Status de Pagamento -->
                <div>
                    <label for="status" class="block text-xs font-semibold text-slate-300 mb-2">Situação *</label>
                    <select name="status" id="status" x-model="status" required
                            class="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                        <option value="pendente">Pendente / A receber</option>
                        <option value="pago" :text="type === 'receita' ? 'Recebido' : 'Pago'">Pago</option>
                    </select>
                </div>

                <!-- Data de Vencimento -->
                <div>
                    <label for="due_date" class="block text-xs font-semibold text-slate-300 mb-2">Data de Vencimento *</label>
                    <input type="date" name="due_date" id="due_date" required value="{{ date('Y-m-d') }}"
                           class="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                </div>

                <!-- Data de Pagamento (Condicional por AlpineJS) -->
                <div x-show="status === 'pago'" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 transform -translate-y-2" x-transition:enter-end="opacity-100 transform translate-y-0">
                    <label for="payment_date" class="block text-xs font-semibold text-slate-300 mb-2">Data de Liquidação *</label>
                    <input type="date" name="payment_date" id="payment_date" :required="status === 'pago'" value="{{ date('Y-m-d') }}"
                           class="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                </div>

                <!-- Conta Financeira -->
                <div>
                    <label for="account_id" class="block text-xs font-semibold text-slate-300 mb-2">Conta / Carteira de Origem *</label>
                    <select name="account_id" id="account_id" required
                            class="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                        <option value="" disabled selected>Selecione uma conta...</option>
                        @foreach($accounts as $acc)
                            <option value="{{ $acc->id }}">{{ $acc->name }} (Saldo: R$ {{ number_format($acc->current_balance, 2, ',', '.') }})</option>
                        @endforeach
                    </select>
                </div>

                <!-- Categoria -->
                <div>
                    <label for="category_id" class="block text-xs font-semibold text-slate-300 mb-2">Categoria *</label>
                    <select name="category_id" id="category_id" required
                            class="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                        <option value="" disabled selected>Selecione uma categoria...</option>
                        @foreach($categories as $cat)
                            <!-- Mostra categorias filtrando pela tipagem no front para facilitar a experiência -->
                            <option value="{{ $cat->id }}" x-show="type === '{{ $cat->type }}'">{{ $cat->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <!-- Comentários / Observações -->
            <div>
                <label for="notes" class="block text-xs font-semibold text-slate-300 mb-2">Observações / Detalhes</label>
                <textarea name="notes" id="notes" rows="3" placeholder="Informações adicionais do lançamento..."
                          class="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-brand-500 transition-colors"></textarea>
            </div>

            <!-- Upload de Anexo -->
            <div>
                <label for="attachment" class="block text-xs font-semibold text-slate-300 mb-2">Anexar Documento / Comprovante (PDF, JPG, PNG)</label>
                <div class="relative flex items-center justify-center border border-dashed border-slate-800 rounded-xl bg-slate-950/20 p-4 hover:bg-slate-950/40 transition-colors">
                    <input type="file" name="attachment" id="attachment" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer">
                    <div class="text-center">
                        <i class="bi bi-cloud-arrow-up text-3xl text-slate-500"></i>
                        <p class="text-xs text-slate-400 mt-1">Arraste ou clique para selecionar o comprovante</p>
                        <p class="text-[10px] text-slate-600 mt-0.5">Tamanho máximo: 4MB</p>
                    </div>
                </div>
            </div>

            <!-- Botões de Ação -->
            <div class="pt-4 border-t border-slate-800/60 flex items-center justify-end gap-4">
                <a href="{{ route('admin.gestao-financeira.transactions.index') }}" class="py-2.5 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm transition-colors text-center">
                    Cancelar
                </a>
                <button type="submit" class="py-2.5 px-6 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-500 hover:from-brand-500 hover:to-indigo-400 text-white font-bold text-sm shadow-lg shadow-brand-500/10 hover:shadow-brand-500/25 transition-all">
                    Salvar Lançamento
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
