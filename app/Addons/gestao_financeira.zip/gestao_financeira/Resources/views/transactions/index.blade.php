@extends(\Illuminate\Support\Facades\View::exists('admin.layouts.master') ? 'admin.layouts.master' : (\Illuminate\Support\Facades\View::exists('admin.master') ? 'admin.master' : 'gestao-financeira::layouts.master'))

@section('title', 'Lançamentos')
@section('page_title', 'Controle de Lançamentos')

@section('content')
<div class="space-y-6">
    <!-- Bloco de Filtros -->
    <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl">
        <form action="{{ route('admin.gestao-financeira.transactions.index') }}" method="GET" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
            <!-- Descrição -->
            <div class="lg:col-span-2">
                <label for="search" class="block text-xs font-semibold text-slate-400 mb-1.5">Pesquisar Lançamento</label>
                <div class="relative">
                    <input type="text" name="search" id="search" value="{{ request('search') }}" placeholder="Ex: Assinatura, Aluguel..." class="w-full pl-9 pr-4 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-brand-500 transition-colors">
                    <div class="absolute left-3 top-2.5 text-slate-500"><i class="bi bi-search"></i></div>
                </div>
            </div>

            <!-- Período: Início -->
            <div>
                <label for="start_date" class="block text-xs font-semibold text-slate-400 mb-1.5">Data Inicial</label>
                <input type="date" name="start_date" id="start_date" value="{{ $startDate }}" class="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
            </div>

            <!-- Período: Fim -->
            <div>
                <label for="end_date" class="block text-xs font-semibold text-slate-400 mb-1.5">Data Final</label>
                <input type="date" name="end_date" id="end_date" value="{{ $endDate }}" class="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
            </div>

            <!-- Tipo -->
            <div>
                <label for="type" class="block text-xs font-semibold text-slate-400 mb-1.5">Tipo</label>
                <select name="type" id="type" class="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                    <option value="">Todos</option>
                    <option value="receita" {{ request('type') === 'receita' ? 'selected' : '' }}>Receitas</option>
                    <option value="despesa" {{ request('type') === 'despesa' ? 'selected' : '' }}>Despesas</option>
                </select>
            </div>

            <!-- Status -->
            <div>
                <label for="status" class="block text-xs font-semibold text-slate-400 mb-1.5">Status</label>
                <select name="status" id="status" class="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                    <option value="">Todos</option>
                    <option value="pago" {{ request('status') === 'pago' ? 'selected' : '' }}>Pago</option>
                    <option value="pendente" {{ request('status') === 'pendente' ? 'selected' : '' }}>Pendente</option>
                </select>
            </div>

            <!-- Conta -->
            <div>
                <label for="account_id" class="block text-xs font-semibold text-slate-400 mb-1.5">Conta</label>
                <select name="account_id" id="account_id" class="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                    <option value="">Todas</option>
                    @foreach($accounts as $acc)
                        <option value="{{ $acc->id }}" {{ request('account_id') == $acc->id ? 'selected' : '' }}>{{ $acc->name }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Categoria -->
            <div>
                <label for="category_id" class="block text-xs font-semibold text-slate-400 mb-1.5">Categoria</label>
                <select name="category_id" id="category_id" class="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                    <option value="">Todas</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}" {{ request('category_id') == $cat->id ? 'selected' : '' }}>{{ $cat->name }} ({{ $cat->type }})</option>
                    @endforeach
                </select>
            </div>

            <!-- Botões de Ação -->
            <div class="lg:col-span-2 flex items-end gap-3">
                <button type="submit" class="flex-1 py-2 px-4 rounded-lg bg-brand-600 hover:bg-brand-500 text-white font-bold text-sm transition-colors flex items-center justify-center gap-2">
                    <i class="bi bi-filter"></i> Filtrar
                </button>
                <a href="{{ route('admin.gestao-financeira.transactions.index') }}" class="py-2 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm transition-colors text-center flex items-center justify-center">
                    Limpar
                </a>
            </div>
        </form>
    </div>

    <!-- Tabela de Lançamentos -->
    <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 overflow-hidden glass-panel shadow-xl">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="border-b border-slate-800 bg-slate-950/40 text-xs font-bold uppercase tracking-wider text-slate-400">
                        <th class="px-6 py-4">Descrição</th>
                        <th class="px-6 py-4">Valor</th>
                        <th class="px-6 py-4">Datas (Venc./Pag.)</th>
                        <th class="px-6 py-4">Conta</th>
                        <th class="px-6 py-4">Categoria</th>
                        <th class="px-6 py-4 text-center">Status</th>
                        <th class="px-6 py-4 text-right">Ações</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/50">
                    @forelse($transactions as $t)
                        <tr class="hover:bg-slate-800/10 transition-colors text-slate-200">
                            <!-- Descrição -->
                            <td class="px-6 py-4">
                                <div class="font-medium text-slate-200 text-sm">{{ $t->description }}</div>
                                @if($t->notes)
                                    <div class="text-[10px] text-slate-500 mt-1 max-w-xs truncate">{{ $t->notes }}</div>
                                @endif
                            </td>
                            
                            <!-- Valor -->
                            <td class="px-6 py-4">
                                <span class="font-bold text-sm {{ $t->type === 'receita' ? 'text-emerald-400' : 'text-rose-400' }}">
                                    {{ $t->type === 'receita' ? '+' : '-' }} R$ {{ number_format($t->amount, 2, ',', '.') }}
                                </span>
                            </td>

                            <!-- Datas -->
                            <td class="px-6 py-4 text-xs space-y-1">
                                <div>
                                    <span class="text-slate-500">Venc.:</span>
                                    <span class="text-slate-300 font-semibold">{{ $t->due_date->format('d/m/Y') }}</span>
                                </div>
                                @if($t->payment_date)
                                    <div>
                                        <span class="text-emerald-500/70">Pago:</span>
                                        <span class="text-emerald-400 font-semibold">{{ $t->payment_date->format('d/m/Y') }}</span>
                                    </div>
                                @endif
                            </td>

                            <!-- Conta -->
                            <td class="px-6 py-4 text-xs font-medium text-slate-300">
                                {{ $t->account->name ?? 'N/A' }}
                            </td>

                            <!-- Categoria -->
                            <td class="px-6 py-4 text-xs">
                                @if($t->category)
                                    <span class="px-2 py-0.5 rounded font-medium border" style="background-color: {{ $t->category->color . '10' }}; color: {{ $t->category->color }}; border-color: {{ $t->category->color . '30' }}">
                                        {{ $t->category->name }}
                                    </span>
                                @else
                                    <span class="text-slate-600">Sem Categoria</span>
                                @endif
                            </td>

                            <!-- Status -->
                            <td class="px-6 py-4 text-center">
                                @if($t->status === 'pago')
                                    <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Pago
                                    </span>
                                @else
                                    <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                        <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span> Pendente
                                    </span>
                                @endif
                            </td>

                            <!-- Ações -->
                            <td class="px-6 py-4 text-right">
                                <div class="flex items-center justify-end gap-2.5">
                                    <!-- Baixa Rápida -->
                                    @if($t->status === 'pendente')
                                        <form action="{{ route('admin.gestao-financeira.transactions.pay', $t->id) }}" method="POST">
                                            @csrf
                                            <button type="submit" title="Confirmar pagamento" class="text-slate-400 hover:text-emerald-400 p-1 text-sm bg-slate-800/40 hover:bg-emerald-500/10 border border-slate-700/50 hover:border-emerald-500/30 rounded transition-all">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                        </form>
                                    @endif

                                    <!-- Ver Anexo -->
                                    @if($t->attachment_path)
                                        <a href="{{ asset('storage/' . $t->attachment_path) }}" target="_blank" title="Ver anexo" class="text-slate-400 hover:text-indigo-400 p-1 text-sm bg-slate-800/40 hover:bg-indigo-500/10 border border-slate-700/50 hover:border-indigo-500/30 rounded transition-all">
                                            <i class="bi bi-paperclip"></i>
                                        </a>
                                    @endif

                                    <!-- Editar -->
                                    <a href="{{ route('admin.gestao-financeira.transactions.edit', $t->id) }}" title="Editar" class="text-slate-400 hover:text-brand-400 p-1 text-sm bg-slate-800/40 hover:bg-brand-500/10 border border-slate-700/50 hover:border-brand-500/30 rounded transition-all">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>

                                    <!-- Excluir -->
                                    <form action="{{ route('admin.gestao-financeira.transactions.destroy', $t->id) }}" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir este lançamento?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" title="Excluir" class="text-slate-400 hover:text-rose-400 p-1 text-sm bg-slate-800/40 hover:bg-rose-500/10 border border-slate-700/50 hover:border-rose-500/30 rounded transition-all">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center text-slate-500">
                                <div class="w-12 h-12 rounded-full bg-slate-800/60 flex items-center justify-center mx-auto mb-3 border border-slate-700/40">
                                    <i class="bi bi-inbox text-lg"></i>
                                </div>
                                <p class="text-sm">Nenhum lançamento encontrado para o filtro selecionado.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- Links de Paginação -->
        @if($transactions->hasPages())
            <div class="px-6 py-4 bg-slate-950/30 border-t border-slate-800/50 flex justify-between items-center">
                {{ $transactions->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
