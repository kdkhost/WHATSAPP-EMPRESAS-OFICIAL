@extends(\Illuminate\Support\Facades\View::exists('admin.layouts.master') ? 'admin.layouts.master' : (\Illuminate\Support\Facades\View::exists('admin.master') ? 'admin.master' : 'gestao-financeira::layouts.master'))

@section('title', 'Relatório de Fluxo de Caixa')
@section('page_title', 'Fluxo de Caixa')

@section('content')
@php
    $totalRecepPagas = 0;
    $totalRecepPendentes = 0;
    $totalDespPagas = 0;
    $totalDespPendentes = 0;

    foreach ($monthsData as $m => $data) {
        $totalRecepPagas += $data['receitas_pagas'];
        $totalRecepPendentes += $data['receitas_pendentes'];
        $totalDespPagas += $data['despesas_pagas'];
        $totalDespPendentes += $data['despesas_pendentes'];
    }

    $saldoRealAno = $totalRecepPagas - $totalDespPagas;
    $saldoProjetadoAno = ($totalRecepPagas + $totalRecepPendentes) - ($totalDespPagas + $totalDespPendentes);

    $nomesMeses = [
        1 => 'Janeiro',
        2 => 'Fevereiro',
        3 => 'Março',
        4 => 'Abril',
        5 => 'Maio',
        6 => 'Junho',
        7 => 'Julho',
        8 => 'Agosto',
        9 => 'Setembro',
        10 => 'Outubro',
        11 => 'Novembro',
        12 => 'Dezembro'
    ];
@endphp

<div class="space-y-8">
    <!-- Breadcrumb & Filters -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.gestao-financeira.reports.index') }}" class="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800/80 flex items-center justify-center text-slate-400 hover:text-slate-200 transition-colors">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <span class="text-xs text-slate-500 font-medium">Relatórios / Demonstrativos</span>
                <h2 class="text-sm font-bold text-slate-300 uppercase tracking-wider">Demonstrativo de Fluxo de Caixa</h2>
            </div>
        </div>
        
        <!-- Year filter -->
        <form action="{{ route('admin.gestao-financeira.reports.cash_flow') }}" method="GET" class="flex items-center gap-3 self-end sm:self-auto">
            <label for="year" class="text-xs text-slate-400 font-semibold">Ano Fiscal:</label>
            <select name="year" id="year" onchange="this.form.submit()" class="bg-slate-900 border border-slate-800/80 text-slate-200 text-xs font-semibold rounded-lg px-3 py-1.5 focus:border-brand-500 focus:outline-none">
                @for($y = now()->year - 3; $y <= now()->year + 1; $y++)
                    <option value="{{ $y }}" {{ $ano == $y ? 'selected' : '' }}>{{ $y }}</option>
                @endfor
            </select>
        </form>
    </div>

    <!-- Annual Consolidation Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Entradas Realizadas -->
        <div class="rounded-xl p-5 glass-card border-slate-800/80 bg-gradient-to-br from-slate-900/60 to-slate-900/40 shadow-lg relative overflow-hidden group">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Recebido</span>
                <div class="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20">
                    <i class="bi bi-arrow-down-left"></i>
                </div>
            </div>
            <h3 class="text-xl font-bold text-emerald-400">
                R$ {{ number_format($totalRecepPagas, 2, ',', '.') }}
            </h3>
            <p class="text-[10px] text-slate-500 mt-1">
                Pendente: <span class="text-slate-400">R$ {{ number_format($totalRecepPendentes, 2, ',', '.') }}</span>
            </p>
        </div>

        <!-- Saídas Realizadas -->
        <div class="rounded-xl p-5 glass-card border-slate-800/80 bg-gradient-to-br from-slate-900/60 to-slate-900/40 shadow-lg relative overflow-hidden group">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Pago</span>
                <div class="w-8 h-8 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400 border border-rose-500/20">
                    <i class="bi bi-arrow-up-right"></i>
                </div>
            </div>
            <h3 class="text-xl font-bold text-rose-400">
                R$ {{ number_format($totalDespPagas, 2, ',', '.') }}
            </h3>
            <p class="text-[10px] text-slate-500 mt-1">
                A Pagar: <span class="text-slate-400">R$ {{ number_format($totalDespPendentes, 2, ',', '.') }}</span>
            </p>
        </div>

        <!-- Saldo Real Consolidado -->
        <div class="rounded-xl p-5 glass-card border-slate-800/80 bg-gradient-to-br from-slate-900/60 to-slate-900/40 shadow-lg relative overflow-hidden group">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Saldo Consolidado</span>
                <div class="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                    <i class="bi bi-wallet2"></i>
                </div>
            </div>
            <h3 class="text-xl font-bold {{ $saldoRealAno >= 0 ? 'text-cyan-400' : 'text-rose-400' }}">
                R$ {{ number_format($saldoRealAno, 2, ',', '.') }}
            </h3>
            <p class="text-[10px] text-slate-500 mt-1">
                Apenas lançamentos liquidados
            </p>
        </div>

        <!-- Saldo Projetado -->
        <div class="rounded-xl p-5 glass-card border-slate-800/80 bg-gradient-to-br from-slate-900/60 to-slate-900/40 shadow-lg relative overflow-hidden group">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Saldo Projetado</span>
                <div class="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20">
                    <i class="bi bi-calendar-event"></i>
                </div>
            </div>
            <h3 class="text-xl font-bold {{ $saldoProjetadoAno >= 0 ? 'text-amber-400' : 'text-rose-400' }}">
                R$ {{ number_format($saldoProjetadoAno, 2, ',', '.') }}
            </h3>
            <p class="text-[10px] text-slate-500 mt-1">
                Considerando previstos e pendentes
            </p>
        </div>
    </div>

    <!-- Chart: Fluxo Mensal -->
    <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl">
        <h4 class="text-sm font-bold text-slate-100 uppercase tracking-wide mb-4">Evolução Mensal do Ano Fiscal</h4>
        <div class="h-72 relative">
            <canvas id="monthlyFlowChart"></canvas>
        </div>
    </div>

    <!-- Monthly Breakdown Table -->
    <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 glass-card shadow-xl overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-850 flex items-center justify-between">
            <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wider">Detalhamento Mensal</h3>
            <button onclick="window.print()" class="text-xs font-bold text-slate-400 hover:text-slate-200 flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg transition-colors">
                <i class="bi bi-printer"></i> Imprimir
            </button>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="bg-slate-900/80 border-b border-slate-800/60 text-slate-400 font-semibold">
                        <th class="py-3.5 px-6">Mês</th>
                        <th class="py-3.5 px-4 text-right">Receitas Pagas</th>
                        <th class="py-3.5 px-4 text-right">Receitas Pendentes</th>
                        <th class="py-3.5 px-4 text-right">Despesas Pagas</th>
                        <th class="py-3.5 px-4 text-right">Despesas Pendentes</th>
                        <th class="py-3.5 px-4 text-right">Saldo do Mês (Real)</th>
                        <th class="py-3.5 px-6 text-right">Saldo do Mês (Projetado)</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/40">
                    @foreach($monthsData as $mesIndex => $data)
                        @php
                            $saldoMesReal = $data['receitas_pagas'] - $data['despesas_pagas'];
                            $saldoMesProj = ($data['receitas_pagas'] + $data['receitas_pendentes']) - ($data['despesas_pagas'] + $data['despesas_pendentes']);
                        @endphp
                        <tr class="hover:bg-slate-800/10 transition-colors">
                            <td class="py-3.5 px-6 font-medium text-slate-300">
                                {{ $nomesMeses[$mesIndex] }}
                            </td>
                            <td class="py-3.5 px-4 text-right text-emerald-400 font-medium">
                                R$ {{ number_format($data['receitas_pagas'], 2, ',', '.') }}
                            </td>
                            <td class="py-3.5 px-4 text-right text-slate-400">
                                R$ {{ number_format($data['receitas_pendentes'], 2, ',', '.') }}
                            </td>
                            <td class="py-3.5 px-4 text-right text-rose-400 font-medium">
                                R$ {{ number_format($data['despesas_pagas'], 2, ',', '.') }}
                            </td>
                            <td class="py-3.5 px-4 text-right text-slate-400">
                                R$ {{ number_format($data['despesas_pendentes'], 2, ',', '.') }}
                            </td>
                            <td class="py-3.5 px-4 text-right font-semibold {{ $saldoMesReal >= 0 ? 'text-emerald-400' : 'text-rose-400' }}">
                                R$ {{ number_format($saldoMesReal, 2, ',', '.') }}
                            </td>
                            <td class="py-3.5 px-6 text-right font-semibold {{ $saldoMesProj >= 0 ? 'text-amber-400' : 'text-rose-400' }}">
                                R$ {{ number_format($saldoMesProj, 2, ',', '.') }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr class="bg-slate-900/60 border-t-2 border-slate-800 text-slate-200 font-bold">
                        <td class="py-4 px-6">Totais</td>
                        <td class="py-4 px-4 text-right text-emerald-400">
                            R$ {{ number_format($totalRecepPagas, 2, ',', '.') }}
                        </td>
                        <td class="py-4 px-4 text-right text-slate-300">
                            R$ {{ number_format($totalRecepPendentes, 2, ',', '.') }}
                        </td>
                        <td class="py-4 px-4 text-right text-rose-400">
                            R$ {{ number_format($totalDespPagas, 2, ',', '.') }}
                        </td>
                        <td class="py-4 px-4 text-right text-slate-300">
                            R$ {{ number_format($totalDespPendentes, 2, ',', '.') }}
                        </td>
                        <td class="py-4 px-4 text-right font-black {{ $saldoRealAno >= 0 ? 'text-emerald-400' : 'text-rose-400' }}">
                            R$ {{ number_format($saldoRealAno, 2, ',', '.') }}
                        </td>
                        <td class="py-4 px-6 text-right font-black {{ $saldoProjetadoAno >= 0 ? 'text-amber-400' : 'text-rose-400' }}">
                            R$ {{ number_format($saldoProjetadoAno, 2, ',', '.') }}
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('monthlyFlowChart').getContext('2d');
        
        // Months labels
        const labels = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        
        // Prepare datasets from backend monthsData
        const rawData = {!! json_encode($monthsData) !!};
        
        const receitasPagas = [];
        const receitasTotal = [];
        const despesasPagas = [];
        const despesasTotal = [];
        
        for (let m = 1; m <= 12; m++) {
            const item = rawData[m];
            receitasPagas.push(item.receitas_pagas);
            receitasTotal.push(item.receitas_pagas + item.receitas_pendentes);
            despesasPagas.push(item.despesas_pagas);
            despesasTotal.push(item.despesas_pagas + item.despesas_pendentes);
        }

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Receitas Realizadas',
                        data: receitasPagas,
                        backgroundColor: 'rgba(16, 185, 129, 0.75)',
                        borderColor: '#10b981',
                        borderWidth: 1.5,
                        borderRadius: 4,
                        hoverBackgroundColor: '#10b981'
                    },
                    {
                        label: 'Receitas Totais (Projetado)',
                        data: receitasTotal,
                        backgroundColor: 'rgba(16, 185, 129, 0.25)',
                        borderColor: 'rgba(16, 185, 129, 0.5)',
                        borderWidth: 1,
                        borderDash: [3, 3],
                        borderRadius: 4
                    },
                    {
                        label: 'Despesas Realizadas',
                        data: despesasPagas,
                        backgroundColor: 'rgba(239, 68, 68, 0.75)',
                        borderColor: '#ef4444',
                        borderWidth: 1.5,
                        borderRadius: 4,
                        hoverBackgroundColor: '#ef4444'
                    },
                    {
                        label: 'Despesas Totais (Projetado)',
                        data: despesasTotal,
                        backgroundColor: 'rgba(239, 68, 68, 0.25)',
                        borderColor: 'rgba(239, 68, 68, 0.5)',
                        borderWidth: 1,
                        borderDash: [3, 3],
                        borderRadius: 4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#94a3b8',
                            font: {
                                size: 10,
                                family: 'Inter'
                            },
                            boxWidth: 12
                        }
                    },
                    tooltip: {
                        padding: 10,
                        backgroundColor: '#1e293b',
                        titleColor: '#f1f5f9',
                        bodyColor: '#cbd5e1',
                        borderColor: '#334155',
                        borderWidth: 1,
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(context.parsed.y);
                                }
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#94a3b8',
                            font: {
                                size: 10,
                                family: 'Inter'
                            }
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(51, 65, 85, 0.15)'
                        },
                        ticks: {
                            color: '#94a3b8',
                            font: {
                                size: 10,
                                family: 'Inter'
                            },
                            callback: function(value) {
                                return 'R$ ' + value.toLocaleString('pt-BR');
                            }
                        }
                    }
                }
            }
        });
    });
</script>
@endsection
