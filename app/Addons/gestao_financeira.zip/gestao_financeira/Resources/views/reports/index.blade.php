@extends(\Illuminate\Support\Facades\View::exists('admin.layouts.master') ? 'admin.layouts.master' : (\Illuminate\Support\Facades\View::exists('admin.master') ? 'admin.master' : 'gestao-financeira::layouts.master'))

@section('title', 'Relatórios Financeiros')
@section('page_title', 'Relatórios & Demonstrativos')

@section('content')
<div class="max-w-6xl mx-auto">
    <!-- Header/Intro -->
    <div class="mb-10 text-center md:text-left">
        <h2 class="text-2xl font-bold text-white tracking-tight">Análise Financeira Avançada</h2>
        <p class="text-sm text-slate-400 mt-2">
            Acompanhe o desempenho de caixa e a saúde financeira do seu negócio através de demonstrativos estruturados.
        </p>
    </div>

    <!-- Cards Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <!-- Fluxo de Caixa Card -->
        <div class="rounded-2xl p-8 glass-card border-slate-800/80 bg-gradient-to-br from-indigo-950/15 via-slate-900/60 to-slate-900/40 shadow-xl flex flex-col justify-between group hover:border-brand-500/30 transition-all duration-300 relative overflow-hidden">
            <!-- Background glow -->
            <div class="absolute -right-16 -top-16 w-36 h-36 rounded-full bg-brand-500/10 blur-3xl group-hover:bg-brand-500/20 transition-all duration-300"></div>
            
            <div>
                <div class="w-14 h-14 rounded-2xl bg-brand-500/10 flex items-center justify-center text-brand-400 border border-brand-500/20 mb-6 group-hover:scale-110 transition-transform duration-300">
                    <i class="bi bi-arrow-down-up text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold text-white mb-3">Fluxo de Caixa Anual</h3>
                <p class="text-slate-400 text-sm leading-relaxed mb-6">
                    Visualize as entradas (receitas) e saídas (despesas) organizadas mês a mês. Compare valores pagos e pendentes para planejar os próximos meses e garantir liquidez de caixa.
                </p>
            </div>
            
            <div class="pt-4 border-t border-slate-800/60 flex items-center justify-between">
                <span class="text-xs text-slate-500">Atualizado em tempo real</span>
                <a href="{{ route('admin.gestao-financeira.reports.cash_flow') }}" class="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-brand-600 hover:bg-brand-500 transition-all duration-200 shadow-md shadow-brand-500/10 hover:shadow-brand-500/25">
                    Acessar Fluxo de Caixa
                    <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>

        <!-- DRE Card -->
        <div class="rounded-2xl p-8 glass-card border-slate-800/80 bg-gradient-to-br from-emerald-950/15 via-slate-900/60 to-slate-900/40 shadow-xl flex flex-col justify-between group hover:border-emerald-500/30 transition-all duration-300 relative overflow-hidden">
            <!-- Background glow -->
            <div class="absolute -right-16 -top-16 w-36 h-36 rounded-full bg-emerald-500/10 blur-3xl group-hover:bg-emerald-500/20 transition-all duration-300"></div>
            
            <div>
                <div class="w-14 h-14 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20 mb-6 group-hover:scale-110 transition-transform duration-300">
                    <i class="bi bi-file-earmark-bar-graph text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold text-white mb-3">DRE (Demonstração do Resultado)</h3>
                <p class="text-slate-400 text-sm leading-relaxed mb-6">
                    Analise a rentabilidade operacional agrupada por categorias de receitas e despesas. Veja o faturamento bruto, custos de operação, lucro líquido consolidado e margem líquida percentual.
                </p>
            </div>
            
            <div class="pt-4 border-t border-slate-800/60 flex items-center justify-between">
                <span class="text-xs text-slate-500">Regime de Caixa</span>
                <a href="{{ route('admin.gestao-financeira.reports.dre') }}" class="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-all duration-200 shadow-md shadow-emerald-500/10 hover:shadow-emerald-500/25">
                    Acessar DRE
                    <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Extra: Dicas de Análise -->
    <div class="rounded-2xl border border-slate-800 bg-slate-900/20 p-6 glass-card shadow-lg">
        <h4 class="text-sm font-bold text-slate-200 flex items-center gap-2 mb-4">
            <i class="bi bi-lightbulb text-amber-400"></i>
            Como utilizar estes demonstrativos?
        </h4>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-400 leading-relaxed">
            <div class="p-4 rounded-xl border border-slate-800/60 bg-slate-950/20">
                <strong class="text-slate-200 block mb-1">Previsão e Liquidez</strong>
                Use o Fluxo de Caixa para identificar gargalos de capital de giro (meses em que as saídas previstas superam as entradas).
            </div>
            <div class="p-4 rounded-xl border border-slate-800/60 bg-slate-950/20">
                <strong class="text-slate-200 block mb-1">Rentabilidade Operacional</strong>
                Use a DRE para avaliar se a sua operação de vendas/serviços de fato gera lucro real após o abatimento de custos de infraestrutura.
            </div>
            <div class="p-4 rounded-xl border border-slate-800/60 bg-slate-950/20">
                <strong class="text-slate-200 block mb-1">Controle de Custos</strong>
                Analise na DRE quais categorias de despesas representam a maior fatia do seu faturamento e busque oportunidades de otimização de custos.
            </div>
        </div>
    </div>
</div>
@endsection
