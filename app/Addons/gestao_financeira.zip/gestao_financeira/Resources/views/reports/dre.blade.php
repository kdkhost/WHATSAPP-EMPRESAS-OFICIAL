@extends(\Illuminate\Support\Facades\View::exists('admin.layouts.master') ? 'admin.layouts.master' : (\Illuminate\Support\Facades\View::exists('admin.master') ? 'admin.master' : 'gestao-financeira::layouts.master'))

@section('title', 'DRE - Demonstrativo do Resultado')
@section('page_title', 'DRE')

@section('content')
<div class="space-y-8">
    <!-- Breadcrumb & Filters -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.gestao-financeira.reports.index') }}" class="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800/80 flex items-center justify-center text-slate-400 hover:text-slate-200 transition-colors">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <span class="text-xs text-slate-500 font-medium">Relatórios / Demonstrativos</span>
                <h2 class="text-sm font-bold text-slate-300 uppercase tracking-wider">Demonstração do Resultado do Exercício</h2>
            </div>
        </div>
        
        <!-- Year filter -->
        <form action="{{ route('admin.gestao-financeira.reports.dre') }}" method="GET" class="flex items-center gap-3 self-end sm:self-auto">
            <label for="year" class="text-xs text-slate-400 font-semibold">Ano Fiscal:</label>
            <select name="year" id="year" onchange="this.form.submit()" class="bg-slate-900 border border-slate-800/80 text-slate-200 text-xs font-semibold rounded-lg px-3 py-1.5 focus:border-brand-500 focus:outline-none">
                @for($y = now()->year - 3; $y <= now()->year + 1; $y++)
                    <option value="{{ $y }}" {{ $ano == $y ? 'selected' : '' }}>{{ $y }}</option>
                @endfor
            </select>
        </form>
    </div>

    <!-- Executive Summary Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Receita Bruta -->
        <div class="rounded-xl p-5 glass-card border-slate-800/80 bg-gradient-to-br from-slate-900/60 to-slate-900/40 shadow-lg">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Faturamento Bruto</span>
                <div class="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20">
                    <i class="bi bi-cash-stack"></i>
                </div>
            </div>
            <h3 class="text-xl font-bold text-emerald-400">
                R$ {{ number_format($totalReceitas, 2, ',', '.') }}
            </h3>
            <p class="text-[10px] text-slate-500 mt-1">Apenas receitas liquidadas no ano</p>
        </div>

        <!-- Despesas Totais -->
        <div class="rounded-xl p-5 glass-card border-slate-800/80 bg-gradient-to-br from-slate-900/60 to-slate-900/40 shadow-lg">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Custos & Despesas</span>
                <div class="w-8 h-8 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400 border border-rose-500/20">
                    <i class="bi bi-wallet2"></i>
                </div>
            </div>
            <h3 class="text-xl font-bold text-rose-400">
                R$ {{ number_format($totalDespesas, 2, ',', '.') }}
            </h3>
            <p class="text-[10px] text-slate-500 mt-1">Apenas despesas liquidadas no ano</p>
        </div>

        <!-- Resultado Líquido -->
        <div class="rounded-xl p-5 glass-card border-slate-800/80 bg-gradient-to-br from-slate-900/60 to-slate-900/40 shadow-lg">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Resultado Líquido</span>
                <div class="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                    <i class="bi bi-calculator"></i>
                </div>
            </div>
            <h3 class="text-xl font-bold {{ $lucroLiquido >= 0 ? 'text-cyan-400' : 'text-rose-400' }}">
                R$ {{ number_format($lucroLiquido, 2, ',', '.') }}
            </h3>
            <p class="text-[10px] text-slate-500 mt-1">
                {{ $lucroLiquido >= 0 ? 'Lucro líquido no ano' : 'Prejuízo líquido no ano' }}
            </p>
        </div>

        <!-- Margem Líquida -->
        <div class="rounded-xl p-5 glass-card border-slate-800/80 bg-gradient-to-br from-slate-900/60 to-slate-900/40 shadow-lg">
            <div class="flex items-center justify-between mb-3">
                <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Margem Líquida</span>
                <div class="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 border border-amber-500/20">
                    <i class="bi bi-percent"></i>
                </div>
            </div>
            <h3 class="text-xl font-bold {{ $margemLiquida >= 0 ? 'text-amber-400' : 'text-rose-400' }}">
                {{ number_format($margemLiquida, 1, ',', '.') }}%
            </h3>
            <p class="text-[10px] text-slate-500 mt-1">Percentual de lucro sobre receita</p>
        </div>
    </div>

    <!-- Charts & Visual Analysis -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Doughnut: Revenues by Category -->
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl">
            <h4 class="text-xs font-bold text-slate-100 uppercase tracking-wide mb-4">Composição de Receitas por Categoria</h4>
            <div class="h-64 relative flex items-center justify-center">
                @if($receitasPorCategoria->count() > 0)
                    <canvas id="receitasChart"></canvas>
                @else
                    <p class="text-xs text-slate-500">Nenhuma receita registrada neste período.</p>
                @endif
            </div>
        </div>

        <!-- Doughnut: Expenses by Category -->
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl">
            <h4 class="text-xs font-bold text-slate-100 uppercase tracking-wide mb-4">Composição de Despesas por Categoria</h4>
            <div class="h-64 relative flex items-center justify-center">
                @if($despesasPorCategoria->count() > 0)
                    <canvas id="despesasChart"></canvas>
                @else
                    <p class="text-xs text-slate-500">Nenhuma despesa registrada neste período.</p>
                @endif
            </div>
        </div>
    </div>

    <!-- Structured DRE Statement -->
    <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 glass-card shadow-xl overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-850 flex items-center justify-between">
            <div>
                <h3 class="text-sm font-bold text-slate-100 uppercase tracking-wider">Estrutura Contábil da DRE</h3>
                <p class="text-[11px] text-slate-500">Regime de Caixa por data de pagamento das transações</p>
            </div>
            <button onclick="window.print()" class="text-xs font-bold text-slate-400 hover:text-slate-200 flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg transition-colors">
                <i class="bi bi-printer"></i> Imprimir DRE
            </button>
        </div>

        <div class="p-6">
            <div class="max-w-4xl mx-auto space-y-4 text-sm font-medium">
                <!-- (+) RECEITAS -->
                <div class="border-b border-slate-800/60 pb-3">
                    <div class="flex items-center justify-between text-slate-200 font-bold text-base py-1">
                        <span>(+) Faturamento Bruto (Entradas)</span>
                        <span class="text-emerald-400">R$ {{ number_format($totalReceitas, 2, ',', '.') }}</span>
                    </div>
                    <!-- Categories Breakdown -->
                    <div class="pl-6 space-y-1.5 mt-2">
                        @forelse($receitasPorCategoria as $c)
                            @php
                                $percent = $totalReceitas > 0 ? ($c->total / $totalReceitas) * 100 : 0;
                            @endphp
                            <div class="flex items-center justify-between text-xs text-slate-400 py-0.5">
                                <span class="flex items-center gap-2">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                    {{ $c->name }}
                                </span>
                                <span>
                                    R$ {{ number_format($c->total, 2, ',', '.') }}
                                    <span class="text-[10px] text-slate-500 ml-1.5">({{ number_format($percent, 1, ',', '.') }}%)</span>
                                </span>
                            </div>
                        @empty
                            <p class="text-xs text-slate-600 pl-4 py-1 italic">Nenhuma receita líquida no período.</p>
                        @endforelse
                    </div>
                </div>

                <!-- (-) DESPESAS -->
                <div class="border-b border-slate-800/60 pb-3">
                    <div class="flex items-center justify-between text-slate-200 font-bold text-base py-1">
                        <span>(-) Custos & Despesas Operacionais (Saídas)</span>
                        <span class="text-rose-400">R$ {{ number_format($totalDespesas, 2, ',', '.') }}</span>
                    </div>
                    <!-- Categories Breakdown -->
                    <div class="pl-6 space-y-1.5 mt-2">
                        @forelse($despesasPorCategoria as $c)
                            @php
                                $percent = $totalDespesas > 0 ? ($c->total / $totalDespesas) * 100 : 0;
                            @endphp
                            <div class="flex items-center justify-between text-xs text-slate-400 py-0.5">
                                <span class="flex items-center gap-2">
                                    <span class="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                                    {{ $c->name }}
                                </span>
                                <span>
                                    R$ {{ number_format($c->total, 2, ',', '.') }}
                                    <span class="text-[10px] text-slate-500 ml-1.5">({{ number_format($percent, 1, ',', '.') }}%)</span>
                                </span>
                            </div>
                        @empty
                            <p class="text-xs text-slate-600 pl-4 py-1 italic">Nenhuma despesa líquida no período.</p>
                        @endforelse
                    </div>
                </div>

                <!-- (=) RESULTADO LÍQUIDO -->
                <div class="rounded-xl p-4 bg-slate-900/60 border border-slate-800/60 flex items-center justify-between">
                    <div>
                        <p class="text-base font-extrabold text-white">(=) RESULTADO LÍQUIDO DO EXERCÍCIO</p>
                        <p class="text-[10px] text-slate-500 font-medium">Margem Líquida Obtida: {{ number_format($margemLiquida, 1, ',', '.') }}%</p>
                    </div>
                    <span class="text-lg font-black {{ $lucroLiquido >= 0 ? 'text-cyan-400' : 'text-rose-400' }}">
                        R$ {{ number_format($lucroLiquido, 2, ',', '.') }}
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
@if($receitasPorCategoria->count() > 0 || $despesasPorCategoria->count() > 0)
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Shared chart options
        const baseOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        color: '#94a3b8',
                        font: {
                            size: 10,
                            family: 'Inter'
                        },
                        boxWidth: 10
                    }
                },
                tooltip: {
                    padding: 8,
                    backgroundColor: '#1e293b',
                    titleColor: '#f1f5f9',
                    bodyColor: '#cbd5e1',
                    borderColor: '#334155',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed !== null) {
                                label += new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(context.parsed);
                            }
                            return label;
                        }
                    }
                }
            }
        };

        // Palette generator
        const baseColors = [
            '#6366f1', '#10b981', '#f59e0b', '#ec4899', '#3b82f6', 
            '#ef4444', '#8b5cf6', '#06b6d4', '#14b8a6', '#84cc16'
        ];

        // 1. Receitas Chart
        @if($receitasPorCategoria->count() > 0)
            const rCtx = document.getElementById('receitasChart').getContext('2d');
            const rData = {!! json_encode($receitasPorCategoria->pluck('total')) !!};
            const rLabels = {!! json_encode($receitasPorCategoria->pluck('name')) !!};
            
            new Chart(rCtx, {
                type: 'doughnut',
                data: {
                    labels: rLabels,
                    datasets: [{
                        data: rData,
                        backgroundColor: baseColors.slice(0, rLabels.length),
                        borderWidth: 1,
                        borderColor: '#0f172a'
                    }]
                },
                options: baseOptions
            });
        @endif

        // 2. Despesas Chart
        @if($despesasPorCategoria->count() > 0)
            const dCtx = document.getElementById('despesasChart').getContext('2d');
            const dData = {!! json_encode($despesasPorCategoria->pluck('total')) !!};
            const dLabels = {!! json_encode($despesasPorCategoria->pluck('name')) !!};
            
            new Chart(dCtx, {
                type: 'doughnut',
                data: {
                    labels: dLabels,
                    datasets: [{
                        data: dData,
                        backgroundColor: baseColors.slice(0, dLabels.length),
                        borderWidth: 1,
                        borderColor: '#0f172a'
                    }]
                },
                options: baseOptions
            });
        @endif
    });
</script>
@endif
@endsection
