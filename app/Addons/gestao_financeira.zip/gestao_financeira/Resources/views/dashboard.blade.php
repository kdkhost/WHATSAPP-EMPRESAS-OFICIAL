@extends(\Illuminate\Support\Facades\View::exists('admin.layouts.master') ? 'admin.layouts.master' : (\Illuminate\Support\Facades\View::exists('admin.master') ? 'admin.master' : 'gestao-financeira::layouts.master'))

@section('title', 'Painel Geral')
@section('page_title', 'Visão Geral Financeira')

@section('content')
<!-- Grid de Estatísticas Rápidas -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- Saldo Consolidado -->
    <div class="rounded-2xl p-6 glass-card border-slate-800 bg-gradient-to-br from-indigo-950/20 to-slate-900/60 shadow-lg relative overflow-hidden group">
        <div class="absolute -right-4 -bottom-4 text-indigo-500/5 group-hover:scale-110 transition-transform duration-300">
            <i class="bi bi-bank text-9xl"></i>
        </div>
        <div class="flex items-center justify-between mb-4">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Saldo Consolidado</span>
            <div class="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                <i class="bi bi-wallet2 text-lg"></i>
            </div>
        </div>
        <h3 class="text-2xl font-bold text-white tracking-tight">
            R$ {{ number_format($saldoContas, 2, ',', '.') }}
        </h3>
        <p class="text-xs text-slate-500 mt-2">Disponível em todas as contas</p>
    </div>

    <!-- Receitas do Mês -->
    <div class="rounded-2xl p-6 glass-card border-slate-800 bg-gradient-to-br from-emerald-950/20 to-slate-900/60 shadow-lg relative overflow-hidden group">
        <div class="absolute -right-4 -bottom-4 text-emerald-500/5 group-hover:scale-110 transition-transform duration-300">
            <i class="bi bi-arrow-up-circle text-9xl"></i>
        </div>
        <div class="flex items-center justify-between mb-4">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Receitas (Mês)</span>
            <div class="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20">
                <i class="bi bi-arrow-up text-lg"></i>
            </div>
        </div>
        <h3 class="text-2xl font-bold text-emerald-400 tracking-tight">
            R$ {{ number_format($receitasRecebidas, 2, ',', '.') }}
        </h3>
        <p class="text-xs text-slate-400 mt-2 flex justify-between">
            <span>Pendente:</span>
            <span class="font-medium text-slate-300">R$ {{ number_format($receitasPendentes, 2, ',', '.') }}</span>
        </p>
    </div>

    <!-- Despesas do Mês -->
    <div class="rounded-2xl p-6 glass-card border-slate-800 bg-gradient-to-br from-rose-950/20 to-slate-900/60 shadow-lg relative overflow-hidden group">
        <div class="absolute -right-4 -bottom-4 text-rose-500/5 group-hover:scale-110 transition-transform duration-300">
            <i class="bi bi-arrow-down-circle text-9xl"></i>
        </div>
        <div class="flex items-center justify-between mb-4">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Despesas (Mês)</span>
            <div class="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-400 border border-rose-500/20">
                <i class="bi bi-arrow-down text-lg"></i>
            </div>
        </div>
        <h3 class="text-2xl font-bold text-rose-400 tracking-tight">
            R$ {{ number_format($despesasPagas, 2, ',', '.') }}
        </h3>
        <p class="text-xs text-slate-400 mt-2 flex justify-between">
            <span>Pendente:</span>
            <span class="font-medium text-slate-300">R$ {{ number_format($despesasPendentes, 2, ',', '.') }}</span>
        </p>
    </div>

    <!-- Resultado Mensal -->
    <div class="rounded-2xl p-6 glass-card border-slate-800 bg-gradient-to-br from-cyan-950/20 to-slate-900/60 shadow-lg relative overflow-hidden group">
        <div class="absolute -right-4 -bottom-4 text-cyan-500/5 group-hover:scale-110 transition-transform duration-300">
            <i class="bi bi-cash text-9xl"></i>
        </div>
        <div class="flex items-center justify-between mb-4">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Resultado Líquido</span>
            <div class="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 border border-cyan-500/20">
                <i class="bi bi-calculator text-lg"></i>
            </div>
        </div>
        <h3 class="text-2xl font-bold tracking-tight {{ $saldoMes >= 0 ? 'text-cyan-400' : 'text-rose-400' }}">
            R$ {{ number_format($saldoMes, 2, ',', '.') }}
        </h3>
        <p class="text-xs text-slate-500 mt-2">Diferença entre entradas e saídas</p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- Gráfico & Contas (Esquerda) -->
    <div class="lg:col-span-2 space-y-8">
        <!-- Fluxo de Caixa Recente (Gráfico) -->
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h4 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Evolução do Fluxo de Caixa</h4>
                    <p class="text-xs text-slate-500">Últimos 6 meses de receitas e despesas pagas</p>
                </div>
                <div class="flex items-center gap-4 text-xs font-semibold">
                    <span class="flex items-center gap-1.5 text-emerald-400">
                        <span class="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span> Receitas
                    </span>
                    <span class="flex items-center gap-1.5 text-rose-400">
                        <span class="w-3 h-3 rounded-full bg-rose-500/80 inline-block"></span> Despesas
                    </span>
                </div>
            </div>
            <!-- Canvas do Gráfico -->
            <div class="h-64 relative">
                <canvas id="flowChart"></canvas>
            </div>
        </div>

        <!-- Contas Bancárias -->
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h4 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Minhas Contas e Carteiras</h4>
                    <p class="text-xs text-slate-500">Saldos atuais detalhados</p>
                </div>
                <a href="{{ route('admin.gestao-financeira.accounts.index') }}" class="text-xs text-brand-400 hover:text-brand-300 font-semibold flex items-center gap-1 transition-colors">
                    Gerenciar Contas <i class="bi bi-arrow-right"></i>
                </a>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                @forelse($contas as $c)
                    <div class="p-4 rounded-xl border border-slate-800 bg-slate-900/60 hover:bg-slate-800/20 transition-all duration-200">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-bold text-slate-400 truncate">{{ $c->name }}</span>
                            @if($c->type === 'digital')
                                <span class="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 uppercase font-extrabold tracking-wider">Digital</span>
                            @elseif($c->type === 'banco')
                                <span class="text-[9px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400 uppercase font-extrabold tracking-wider">Banco</span>
                            @elseif($c->type === 'dinheiro')
                                <span class="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 uppercase font-extrabold tracking-wider">Físico</span>
                            @else
                                <span class="text-[9px] px-1.5 py-0.5 rounded bg-slate-500/10 text-slate-400 uppercase font-extrabold tracking-wider">Outro</span>
                            @endif
                        </div>
                        <p class="text-lg font-bold text-white">
                            R$ {{ number_format($c->current_balance, 2, ',', '.') }}
                        </p>
                    </div>
                @empty
                    <p class="col-span-3 text-sm text-slate-500 text-center py-4">Nenhuma conta cadastrada.</p>
                @endforelse
            </div>
        </div>
    </div>

    <!-- Transações Recentes & Contas a Pagar (Direita) -->
    <div class="space-y-8">
        <!-- Lançamentos Futuros / Vencimentos -->
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h4 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Próximos 7 Dias</h4>
                    <p class="text-xs text-slate-500">Lançamentos pendentes a vencer</p>
                </div>
                <span class="text-xs px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/25 font-bold">{{ $upcomingTransactions->count() }}</span>
            </div>

            <div class="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                @forelse($upcomingTransactions as $t)
                    <div class="p-3 rounded-xl border border-slate-800 bg-slate-950/45 flex items-center justify-between gap-3 hover:border-slate-700/60 transition-colors">
                        <div class="min-w-0 flex-1">
                            <p class="text-xs font-semibold text-slate-200 truncate">{{ $t->description }}</p>
                            <div class="flex items-center gap-1.5 mt-1 text-[10px] text-slate-500">
                                <span class="truncate">{{ $t->due_date->format('d/m') }}</span>
                                <span>•</span>
                                <span class="px-1.5 py-0.5 rounded-sm truncate" style="background-color: {{ ($t->category->color ?? '#6B7280') . '1A' }}; color: {{ $t->category->color ?? '#6B7280' }}">{{ $t->category->name ?? 'Sem Cat' }}</span>
                            </div>
                        </div>
                        <div class="text-right flex flex-col items-end gap-1.5 shrink-0">
                            <span class="text-xs font-bold {{ $t->type === 'receita' ? 'text-emerald-400' : 'text-rose-400' }}">
                                {{ $t->type === 'receita' ? '+' : '-' }} R$ {{ number_format($t->amount, 2, ',', '.') }}
                            </span>
                            <form action="{{ route('admin.gestao-financeira.transactions.pay', $t->id) }}" method="POST">
                                @csrf
                                <button type="submit" class="text-[9px] px-2 py-0.5 rounded-md bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-white transition-all font-bold">
                                    Pagar
                                </button>
                            </form>
                        </div>
                    </div>
                @empty
                    <div class="text-center py-8">
                        <div class="w-10 h-10 rounded-full bg-slate-800/80 flex items-center justify-center mx-auto mb-2 border border-slate-700/50">
                            <i class="bi bi-shield-check text-slate-400"></i>
                        </div>
                        <p class="text-xs text-slate-500">Tudo limpo para os próximos dias!</p>
                    </div>
                @endforelse
            </div>
        </div>

        <!-- Últimas Transações -->
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h4 class="text-sm font-bold text-slate-100 uppercase tracking-wide">Últimas Transações</h4>
                    <p class="text-xs text-slate-500">Histórico geral recente</p>
                </div>
                <a href="{{ route('admin.gestao-financeira.transactions.index') }}" class="text-xs text-brand-400 hover:text-brand-300 font-semibold transition-colors">Ver todas</a>
            </div>

            <div class="space-y-3">
                @forelse($recentTransactions as $t)
                    <div class="flex items-center justify-between gap-4 p-2 rounded-lg hover:bg-slate-800/20 transition-colors">
                        <div class="flex items-center gap-3 min-w-0">
                            <div class="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 {{ $t->type === 'receita' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20' }}">
                                <i class="bi {{ $t->type === 'receita' ? 'bi-arrow-down-left' : 'bi-arrow-up-right' }}"></i>
                            </div>
                            <div class="min-w-0">
                                <p class="text-xs font-semibold text-slate-200 truncate">{{ $t->description }}</p>
                                <p class="text-[9px] text-slate-500 mt-0.5">{{ $t->due_date->format('d/m/Y') }}</p>
                            </div>
                        </div>
                        <div class="text-right shrink-0">
                            <p class="text-xs font-bold {{ $t->type === 'receita' ? 'text-emerald-400' : 'text-rose-400' }}">
                                {{ $t->type === 'receita' ? '+' : '-' }} R$ {{ number_format($t->amount, 2, ',', '.') }}
                            </p>
                            <span class="text-[8px] uppercase tracking-wider font-extrabold px-1 rounded-sm {{ $t->status === 'pago' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500' }}">
                                {{ $t->status }}
                            </span>
                        </div>
                    </div>
                @empty
                    <p class="text-xs text-slate-500 text-center py-6">Nenhuma transação lançada.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<!-- ChartJS via CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('flowChart').getContext('2d');
        
        const gradientReceitas = ctx.createLinearGradient(0, 0, 0, 240);
        gradientReceitas.addColorStop(0, 'rgba(16, 185, 129, 0.2)');
        gradientReceitas.addColorStop(1, 'rgba(16, 185, 129, 0)');

        const gradientDespesas = ctx.createLinearGradient(0, 0, 0, 240);
        gradientDespesas.addColorStop(0, 'rgba(239, 68, 68, 0.2)');
        gradientDespesas.addColorStop(1, 'rgba(239, 68, 68, 0)');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: {!! json_encode($chartData['labels']) !!},
                datasets: [
                    {
                        label: 'Receitas (R$)',
                        data: {!! json_encode($chartData['receitas']) !!},
                        borderColor: '#10b981',
                        borderWidth: 2,
                        backgroundColor: gradientReceitas,
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: '#10b981',
                        pointHoverRadius: 6
                    },
                    {
                        label: 'Despesas (R$)',
                        data: {!! json_encode($chartData['despesas']) !!},
                        borderColor: '#ef4444',
                        borderWidth: 2,
                        backgroundColor: gradientDespesas,
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: '#ef4444',
                        pointHoverRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        padding: 10,
                        backgroundColor: '#1e293b',
                        titleColor: '#f1f5f9',
                        bodyColor: '#cbd5e1',
                        borderColor: '#334155',
                        borderWidth: 1,
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(context.parsed.y);
                                }
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#94a3b8',
                            font: {
                                size: 10,
                                family: 'Inter'
                            }
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(51, 65, 85, 0.2)'
                        },
                        ticks: {
                            color: '#94a3b8',
                            font: {
                                size: 10,
                                family: 'Inter'
                            },
                            callback: function(value) {
                                return 'R$ ' + value.toLocaleString('pt-BR');
                            }
                        }
                    }
                }
            }
        });
    });
</script>
@endsection
