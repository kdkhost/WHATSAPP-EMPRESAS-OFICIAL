@extends(\Illuminate\Support\Facades\View::exists('admin.layouts.master') ? 'admin.layouts.master' : (\Illuminate\Support\Facades\View::exists('admin.master') ? 'admin.master' : 'gestao-financeira::layouts.master'))

@section('title', 'Categorias')
@section('page_title', 'Gerenciar Categorias')

@section('content')
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8" x-data="{ 
    editMode: false, 
    actionRoute: '{{ route('admin.gestao-financeira.categories.store') }}',
    catId: '',
    catName: '', 
    catType: 'receita', 
    catColor: '#3B82F6',
    
    startEdit(category) {
        this.editMode = true;
        this.catId = category.id;
        this.catName = category.name;
        this.catType = category.type;
        this.catColor = category.color;
        this.actionRoute = '{{ url('admin/gestao-financeira/categorias') }}/' + category.id + '/atualizar';
    },
    
    cancelEdit() {
        this.editMode = false;
        this.catId = '';
        this.catName = '';
        this.catType = 'receita';
        this.catColor = '#3B82F6';
        this.actionRoute = '{{ route('admin.gestao-financeira.categories.store') }}';
    }
}">
    <!-- Lista de Categorias (Esquerda) -->
    <div class="lg:col-span-2">
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 overflow-hidden glass-panel shadow-xl">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="border-b border-slate-800 bg-slate-950/40 text-xs font-bold uppercase tracking-wider text-slate-400">
                        <th class="px-6 py-4">Nome da Categoria</th>
                        <th class="px-6 py-4">Tipo</th>
                        <th class="px-6 py-4">Identificador Visual</th>
                        <th class="px-6 py-4 text-center">Nº Lançamentos</th>
                        <th class="px-6 py-4 text-right">Ações</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/50">
                    @forelse($categories as $c)
                        <tr class="hover:bg-slate-800/10 transition-colors text-slate-200">
                            <!-- Nome -->
                            <td class="px-6 py-4 font-semibold text-sm">
                                {{ $c->name }}
                            </td>
                            
                            <!-- Tipo -->
                            <td class="px-6 py-4 text-xs font-semibold">
                                @if($c->type === 'receita')
                                    <span class="text-emerald-400"><i class="bi bi-arrow-down-left mr-1"></i> Receita</span>
                                @else
                                    <span class="text-rose-400"><i class="bi bi-arrow-up-right mr-1"></i> Despesa</span>
                                @endif
                            </td>

                            <!-- Cor -->
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-2">
                                    <span class="w-4 h-4 rounded-full border border-slate-700/60 inline-block shrink-0 shadow" style="background-color: {{ $c->color }}"></span>
                                    <span class="text-xs font-mono text-slate-400">{{ $c->color }}</span>
                                </div>
                            </td>

                            <!-- Lançamentos vinculados -->
                            <td class="px-6 py-4 text-center text-xs font-medium text-slate-400">
                                {{ $c->transactions_count }}
                            </td>

                            <!-- Ações -->
                            <td class="px-6 py-4 text-right">
                                <div class="flex items-center justify-end gap-3">
                                    <!-- Editar (Gatilho Alpine) -->
                                    <button @click="startEdit({{ json_encode($c) }})" title="Editar Categoria" class="text-slate-400 hover:text-brand-400 p-1 text-sm bg-slate-800/40 hover:bg-brand-500/10 border border-slate-700/50 hover:border-brand-500/30 rounded transition-all">
                                        <i class="bi bi-pencil-square"></i>
                                    </button>

                                    <!-- Excluir -->
                                    <form action="{{ route('admin.gestao-financeira.categories.destroy', $c->id) }}" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir esta categoria? As transações vinculadas a ela passarão a ficar sem categoria.')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" title="Excluir" class="text-slate-400 hover:text-rose-400 p-1 text-sm bg-slate-800/40 hover:bg-rose-500/10 border border-slate-700/50 hover:border-rose-500/30 rounded transition-all">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-slate-500">
                                <p class="text-sm">Nenhuma categoria cadastrada.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Formulário Dinâmico (Direita) -->
    <div>
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl sticky top-6">
            <h4 class="text-sm font-bold text-slate-100 uppercase tracking-wide mb-4" x-text="editMode ? 'Editar Categoria' : 'Nova Categoria'"></h4>
            
            <form :action="actionRoute" method="POST" class="space-y-4">
                @csrf
                
                <!-- Nome -->
                <div>
                    <label for="name" class="block text-xs font-semibold text-slate-300 mb-1.5">Nome da Categoria *</label>
                    <input type="text" name="name" id="name" required x-model="catName" placeholder="Ex: Investimentos, Freelance..." 
                           class="w-full px-4 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-brand-500 transition-colors">
                </div>

                <!-- Tipo -->
                <div>
                    <label for="type" class="block text-xs font-semibold text-slate-300 mb-1.5">Tipo de Fluxo *</label>
                    <select name="type" id="type" required x-model="catType"
                            class="w-full px-4 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                        <option value="receita">Receita (Entrada)</option>
                        <option value="despesa">Despesa (Saída)</option>
                    </select>
                </div>

                <!-- Cor para gráficos -->
                <div>
                    <label for="color" class="block text-xs font-semibold text-slate-300 mb-1.5">Cor Identificadora *</label>
                    <div class="flex items-center gap-3">
                        <input type="color" name="color" id="color" required x-model="catColor"
                               class="w-10 h-10 border-0 rounded bg-transparent cursor-pointer shrink-0">
                        <input type="text" x-model="catColor" readonly
                               class="w-full px-4 py-2 text-xs font-mono rounded-lg bg-slate-950 border border-slate-800 text-slate-400 focus:outline-none">
                    </div>
                </div>

                <!-- Botões de Ação -->
                <div class="pt-4 border-t border-slate-800/60 flex items-center justify-end gap-3">
                    <button type="button" x-show="editMode" @click="cancelEdit()"
                            class="py-2 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors">
                        Cancelar
                    </button>
                    <button type="submit" class="py-2 px-4 rounded-lg bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs transition-all shadow-md shadow-brand-500/10">
                        <span x-text="editMode ? 'Salvar Alterações' : 'Cadastrar Categoria'"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
