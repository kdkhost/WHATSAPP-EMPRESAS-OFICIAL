@extends(\Illuminate\Support\Facades\View::exists('admin.layouts.master') ? 'admin.layouts.master' : (\Illuminate\Support\Facades\View::exists('admin.master') ? 'admin.master' : 'gestao-financeira::layouts.master'))

@section('title', 'Contas')
@section('page_title', 'Contas e Carteiras')

@section('content')
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8" x-data="{ 
    editMode: false, 
    actionRoute: '{{ route('admin.gestao-financeira.accounts.store') }}',
    accId: '',
    accName: '', 
    accType: 'banco', 
    accInitial: '0.00',
    accDesc: '',
    
    startEdit(account) {
        this.editMode = true;
        this.accId = account.id;
        this.accName = account.name;
        this.accType = account.type;
        this.accDesc = account.description || '';
        this.actionRoute = '{{ url('admin/gestao-financeira/contas') }}/' + account.id + '/atualizar';
    },
    
    cancelEdit() {
        this.editMode = false;
        this.accId = '';
        this.accName = '';
        this.accType = 'banco';
        this.accInitial = '0.00';
        this.accDesc = '';
        this.actionRoute = '{{ route('admin.gestao-financeira.accounts.store') }}';
    }
}">
    <!-- Lista de Contas (Esquerda) -->
    <div class="lg:col-span-2">
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 overflow-hidden glass-panel shadow-xl">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="border-b border-slate-800 bg-slate-950/40 text-xs font-bold uppercase tracking-wider text-slate-400">
                        <th class="px-6 py-4">Nome da Conta</th>
                        <th class="px-6 py-4">Tipo</th>
                        <th class="px-6 py-4">Saldo Atual</th>
                        <th class="px-6 py-4 text-center">Nº Lançamentos</th>
                        <th class="px-6 py-4 text-right">Ações</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/50">
                    @forelse($accounts as $a)
                        <tr class="hover:bg-slate-800/10 transition-colors text-slate-200">
                            <!-- Nome e Descrição -->
                            <td class="px-6 py-4">
                                <div class="font-semibold text-sm text-slate-200">{{ $a->name }}</div>
                                @if($a->description)
                                    <div class="text-[10px] text-slate-500 mt-0.5">{{ $a->description }}</div>
                                @endif
                            </td>
                            
                            <!-- Tipo -->
                            <td class="px-6 py-4 text-xs font-semibold uppercase tracking-wider">
                                @if($a->type === 'digital')
                                    <span class="text-cyan-400">Digital</span>
                                @elseif($a->type === 'banco')
                                    <span class="text-indigo-400">Banco</span>
                                @elseif($a->type === 'dinheiro')
                                    <span class="text-amber-400">Físico</span>
                                @elseif($a->type === 'cartao')
                                    <span class="text-purple-400">Cartão</span>
                                @else
                                    <span class="text-slate-400">Outro</span>
                                @endif
                            </td>

                            <!-- Saldo Atual -->
                            <td class="px-6 py-4">
                                <span class="font-bold text-sm text-slate-100">
                                    R$ {{ number_format($a->current_balance, 2, ',', '.') }}
                                </span>
                            </td>

                            <!-- Lançamentos -->
                            <td class="px-6 py-4 text-center text-xs font-medium text-slate-400">
                                {{ $a->transactions_count }}
                            </td>

                            <!-- Ações -->
                            <td class="px-6 py-4 text-right">
                                <div class="flex items-center justify-end gap-3">
                                    <!-- Editar -->
                                    <button @click="startEdit({{ json_encode($a) }})" title="Editar Conta" class="text-slate-400 hover:text-brand-400 p-1 text-sm bg-slate-800/40 hover:bg-brand-500/10 border border-slate-700/50 hover:border-brand-500/30 rounded transition-all">
                                        <i class="bi bi-pencil-square"></i>
                                    </button>

                                    <!-- Excluir -->
                                    <form action="{{ route('admin.gestao-financeira.accounts.destroy', $a->id) }}" method="POST" onsubmit="return confirm('Deseja excluir esta conta? Só será possível caso não existam lançamentos vinculados a ela.')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" title="Excluir" class="text-slate-400 hover:text-rose-400 p-1 text-sm bg-slate-800/40 hover:bg-rose-500/10 border border-slate-700/50 hover:border-rose-500/30 rounded transition-all">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center text-slate-500">
                                <p class="text-sm">Nenhuma conta cadastrada.</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Formulário Dinâmico (Direita) -->
    <div>
        <div class="rounded-2xl border border-slate-800/80 bg-slate-900/35 p-6 glass-card shadow-xl sticky top-6">
            <h4 class="text-sm font-bold text-slate-100 uppercase tracking-wide mb-4" x-text="editMode ? 'Editar Conta' : 'Nova Conta'"></h4>
            
            <form :action="actionRoute" method="POST" class="space-y-4">
                @csrf
                
                <!-- Nome -->
                <div>
                    <label for="name" class="block text-xs font-semibold text-slate-300 mb-1.5">Nome da Conta *</label>
                    <input type="text" name="name" id="name" required x-model="accName" placeholder="Ex: Banco Itaú, Carteira Pix..." 
                           class="w-full px-4 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-brand-500 transition-colors">
                </div>

                <!-- Tipo -->
                <div>
                    <label for="type" class="block text-xs font-semibold text-slate-300 mb-1.5">Tipo de Conta *</label>
                    <select name="type" id="type" required x-model="accType"
                            class="w-full px-4 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                        <option value="banco">Conta Bancária</option>
                        <option value="digital">Carteira Digital</option>
                        <option value="dinheiro">Dinheiro Físico</option>
                        <option value="cartao">Cartão de Crédito</option>
                        <option value="outro">Outro</option>
                    </select>
                </div>

                <!-- Saldo Inicial (Oculto no Edit) -->
                <div x-show="!editMode">
                    <label for="initial_balance" class="block text-xs font-semibold text-slate-300 mb-1.5">Saldo Inicial (R$) *</label>
                    <div class="relative">
                        <input type="number" step="0.01" name="initial_balance" id="initial_balance" x-model="accInitial" required
                               class="w-full pl-12 pr-4 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-brand-500 transition-colors">
                        <div class="absolute left-4 top-2.5 text-xs font-bold text-slate-500">R$</div>
                    </div>
                    <p class="text-[10px] text-slate-500 mt-1">Saldo inicial disponível antes das movimentações no painel.</p>
                </div>

                <!-- Descrição -->
                <div>
                    <label for="description" class="block text-xs font-semibold text-slate-300 mb-1.5">Observações / Detalhes</label>
                    <textarea name="description" id="description" rows="2" x-model="accDesc" placeholder="Agência, Conta, Chave Pix associada..."
                              class="w-full px-4 py-2 text-sm rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-brand-500 transition-colors"></textarea>
                </div>

                <!-- Botões de Ação -->
                <div class="pt-4 border-t border-slate-800/60 flex items-center justify-end gap-3">
                    <button type="button" x-show="editMode" @click="cancelEdit()"
                            class="py-2 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors">
                        Cancelar
                    </button>
                    <button type="submit" class="py-2 px-4 rounded-lg bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs transition-all shadow-md shadow-brand-500/10">
                        <span x-text="editMode ? 'Salvar Alterações' : 'Cadastrar Conta'"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
