<!DOCTYPE html>
<html lang="pt-BR" class="h-full bg-slate-950">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Financeiro') | Gestão Financeira Completa</title>
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- AlpineJS for interactive elements -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            50: '#eef2ff',
                            100: '#e0e7ff',
                            200: '#c7d2fe',
                            300: '#a5b4fc',
                            400: '#818cf8',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                            800: '#3730a3',
                            900: '#312e81',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        /* Glassmorphism custom styles */
        .glass-panel {
            background: rgba(15, 23, 42, 0.45);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.5);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.5);
        }
        ::-webkit-scrollbar-thumb {
            background: rgba(99, 102, 241, 0.3);
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: rgba(99, 102, 241, 0.6);
        }
    </style>
    @yield('styles')
</head>
<body class="h-full text-slate-100 font-sans antialiased bg-slate-950 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-950/40 via-slate-950 to-slate-950">

    <div class="min-h-full flex flex-col md:flex-row">
        <!-- Sidebar -->
        <aside class="w-full md:w-64 bg-slate-900/90 border-b md:border-b-0 md:border-r border-slate-800/80 flex flex-col justify-between shrink-0 glass-panel">
            <div>
                <!-- Brand logo -->
                <div class="h-16 flex items-center px-6 border-b border-slate-800/60 justify-between">
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-lg bg-gradient-to-tr from-brand-600 to-indigo-400 flex items-center justify-center shadow-lg shadow-brand-500/20">
                            <i class="bi bi-wallet2 text-white text-base"></i>
                        </div>
                        <span class="font-extrabold text-lg bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-slate-400 tracking-tight">KDK Finance</span>
                    </div>
                    <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-brand-500/10 text-brand-400 border border-brand-500/20">ADDON</span>
                </div>

                <!-- Navigation Links -->
                <nav class="p-4 space-y-1.5">
                    <a href="{{ route('admin.gestao-financeira.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 {{ Route::is('admin.gestao-financeira.index') ? 'bg-brand-600 text-white shadow-md shadow-brand-500/10' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40' }}">
                        <i class="bi bi-grid text-lg"></i>
                        Dashboard
                    </a>
                    <a href="{{ route('admin.gestao-financeira.transactions.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 {{ Route::is('admin.gestao-financeira.transactions.*') ? 'bg-brand-600 text-white shadow-md shadow-brand-500/10' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40' }}">
                        <i class="bi bi-arrow-down-up text-lg"></i>
                        Lançamentos
                    </a>
                    <a href="{{ route('admin.gestao-financeira.categories.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 {{ Route::is('admin.gestao-financeira.categories.index') ? 'bg-brand-600 text-white shadow-md shadow-brand-500/10' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40' }}">
                        <i class="bi bi-tags text-lg"></i>
                        Categorias
                    </a>
                    <a href="{{ route('admin.gestao-financeira.accounts.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 {{ Route::is('admin.gestao-financeira.accounts.index') ? 'bg-brand-600 text-white shadow-md shadow-brand-500/10' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40' }}">
                        <i class="bi bi-bank text-lg"></i>
                        Contas
                    </a>
                    <a href="{{ route('admin.gestao-financeira.reports.index') }}" class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 {{ Route::is('admin.gestao-financeira.reports.*') ? 'bg-brand-600 text-white shadow-md shadow-brand-500/10' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40' }}">
                        <i class="bi bi-file-earmark-bar-graph text-lg"></i>
                        Relatórios
                    </a>
                </nav>
            </div>

            <!-- User / Environment status -->
            <div class="p-4 border-t border-slate-800/60 bg-slate-950/20">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-brand-400 font-bold text-sm">
                        ADM
                    </div>
                    <div class="min-w-0 flex-1">
                        <p class="text-xs font-semibold text-slate-200 truncate">Administrador</p>
                        <p class="text-[10px] text-slate-500 truncate">Painel Financeiro</p>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main Content Area -->
        <main class="flex-1 flex flex-col min-w-0">
            <!-- Header navbar -->
            <header class="h-16 border-b border-slate-800/80 bg-slate-900/40 flex items-center justify-between px-6 md:px-8 glass-panel shrink-0">
                <h1 class="text-lg font-bold text-slate-100">@yield('page_title', 'Financeiro')</h1>
                <div class="flex items-center gap-4">
                    <!-- New entry quick button -->
                    <a href="{{ route('admin.gestao-financeira.transactions.create') }}" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-gradient-to-tr from-brand-600 to-indigo-500 hover:from-brand-500 hover:to-indigo-400 transition-all duration-200 shadow-md shadow-brand-500/10 hover:shadow-brand-500/25 active:scale-95">
                        <i class="bi bi-plus-lg"></i>
                        Novo Lançamento
                    </a>
                </div>
            </header>

            <!-- Page Body -->
            <div class="flex-1 p-6 md:p-8 overflow-y-auto">
                <!-- Notifications -->
                @if(session('success'))
                    <div x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 5000)" class="mb-6 p-4 rounded-xl border border-emerald-500/20 bg-emerald-500/10 text-emerald-400 flex items-center justify-between shadow-lg shadow-emerald-950/20 transition-all duration-300">
                        <div class="flex items-center gap-3">
                            <i class="bi bi-check-circle-fill text-lg"></i>
                            <span class="text-sm font-medium">{{ session('success') }}</span>
                        </div>
                        <button @click="show = false" class="text-emerald-400/60 hover:text-emerald-400"><i class="bi bi-x-lg"></i></button>
                    </div>
                @endif

                @if(session('error'))
                    <div x-data="{ show: true }" x-show="show" x-init="setTimeout(() => show = false, 6000)" class="mb-6 p-4 rounded-xl border border-rose-500/20 bg-rose-500/10 text-rose-400 flex items-center justify-between shadow-lg shadow-rose-950/20 transition-all duration-300">
                        <div class="flex items-center gap-3">
                            <i class="bi bi-exclamation-triangle-fill text-lg"></i>
                            <span class="text-sm font-medium">{{ session('error') }}</span>
                        </div>
                        <button @click="show = false" class="text-rose-400/60 hover:text-rose-400"><i class="bi bi-x-lg"></i></button>
                    </div>
                @endif

                @yield('content')
            </div>
        </main>
    </div>

    @yield('scripts')
</body>
</html>
